export class UserLogin{
    constructor(
        public userEmail: string = '',
        public userPassword: string = '',
    ){}
}